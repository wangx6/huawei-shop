package com.huawei.apidemotest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

public class IDTokenAPIDemo1 {
    public static void main(String[] args) throws IOException {

        //common parameters
        String urlTokenInfo = "https://oauth-login.cloud.huawei.com/oauth2/v3/tokeninfo";
		//idToken which server have got.
        String idToken = "eyJraWQiOiJiNDA1NTEyYzdkZTRhZDUyMWQ5MDg5MTgyMmQzMzNhNjNkZmMyNmY3OTQzNGY2N2QxMDM1NjJjZWYwY2NkMmQ5IiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiRjBGeVpRNXdwUXdfb282Wl8yd0ZSZyIsImF1ZCI6IjMwMDAzNTIzMyIsInN1YiI6Ik1ERUxhWkd4UTlXaHFIVnFrRVZZcVZYblF5TFhqcDhyVmhmbWxScHg4SjlYclEiLCJhenAiOiIzMDAwMzUyMzMiLCJpc3MiOiJodHRwczovL2FjY291bnRzLmh1YXdlaS5jb20iLCJuYW1lIjoi6Jab5oyv5Y2OIiwiZXhwIjoxNTcxODIwODYyLCJnaXZlbl9uYW1lIjoi6Jab5oyv5Y2OIiwiZGlzcGxheV9uYW1lIjoi56m65oyH6ZKIMeWPtyIsImlhdCI6MTU3MTgxNzI2Miwibm9uY2UiOiIzNmUwM2I3NS01MmFkLTQ1ODktYTgwZC1jNDJkODk3Y2Q2NWYiLCJwaWN0dXJlIjoiaHR0cHM6Ly9od2xmLmh3Y2xvdWR0ZXN0LmNuL0ZpbGVTZXJ2ZXIvaW1hZ2UvYi4wMDcwMDg2MDAwMDAwMDgyNDA2LjIwMTkwNzI3MTU0ODUwLkFWZ25SVmtlWHhsd1E3Q3lNTjlrUGZEVmR6U1lCVWtFLjEwMDAuNjQ2RTJGOUNCNDA4Rjc0NDVFMTkwRDVEOUEyNjMwNThBOUZFMjM2NDMzMUUyM0M2OTFEQjgwRTYxMzE4NzNGRC5wbmcifQ.jUqXcX1clZX91avNGWMfqyjSR42B0KupBWCjEPni3DxUQzTYOrz8FsrAtDVLRjAd_YJ4K1_3_f--mt18pGOBiy_Z2ScGqOg0kNwVYw1_5hp7-dbb9b3vjefQcOkkvUGG3TOwHPtFzeetA3H5mKe56ZdVWoH243OPgoFHm32vJY0EA74ClYVK6wObhbThzNzYleTznd1wmxtv2SkNWI-dlEialfxR7M9HK9_DqsE1gmRLivlVVwyIeUetb_jjxWwg0LxNV2oxpoDsyz2rUPozT_kqtMtsLyHS-ATfLhZSSBS5avphaNsUZh0jdz3knOvQaii3gp20XZtreOARS71DqA";
        JSONObject tokenInfo = getDetailByIDToken(urlTokenInfo,idToken);
        System.out.println("the output of /oauth2/v3/tokeninfo is : " + tokenInfo.toJSONString());
    }

    private static JSONObject getDetailByIDToken(String urlTokenInfo, String idToken) throws IOException {
        StringBuilder stringBuilder = new StringBuilder("");
        stringBuilder.append("id_token=").append(URLEncoder.encode(idToken, "UTF-8"));

        HttpGet httpGet = new HttpGet(urlTokenInfo + "?" + stringBuilder);
        CloseableHttpResponse response = getClient().execute(httpGet);

        try {
            HttpEntity responseEntity = response.getEntity();
            String ret = responseEntity != null ? EntityUtils.toString(responseEntity) : null;
            JSONObject jsonObject = (JSONObject) JSON.parse(ret);
            EntityUtils.consume(responseEntity);
            return jsonObject;
        } finally {
            response.close();
        }

    }

    /**
     * get httpclient
     * @return
     */
    private static CloseableHttpClient getClient() {
        PoolingHttpClientConnectionManager connectionManager = buildConnectionManager("TLSv1.2", new String[]{"TLSv1.2","TLSv1.1"},
                new String[]{"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","TLS_DHE_RSA_WITH_AES_128_CBC_SHA256", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA", "TLS_DHE_DSS_WITH_AES_128_CBC_SHA"});
        connectionManager.setMaxTotal(400);
        connectionManager.setDefaultMaxPerRoute(400);
        RequestConfig config =
                RequestConfig.custom().setConnectionRequestTimeout(100).setRedirectsEnabled(false).build();

        return HttpClients.custom()
                .useSystemProperties()
                .setConnectionManager(connectionManager)
                .setDefaultRequestConfig(config)
                .build();
    }

    /**
     *
     * @param protocol
     * @param supportedProtocols
     * @param supportedCipherSuites
     * @return
     */
    private static PoolingHttpClientConnectionManager buildConnectionManager(String protocol,
                                                                             String[] supportedProtocols, String[] supportedCipherSuites) {
        PoolingHttpClientConnectionManager connectionManager = null;
        try {
            SSLContext sc = SSLContext.getInstance(protocol);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init((KeyStore) null);
            sc.init(null, tmf.getTrustManagers(), null);
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sc, supportedProtocols,
                    supportedCipherSuites, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslsf)
                    .build();
            connectionManager = new PoolingHttpClientConnectionManager(registry);
        } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
            e.printStackTrace();
        }
        return connectionManager;
    }
}
