package com.huawei.apidemotest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class TokenAPIDemo1 {
    public static void main(String[] args) throws IOException {

        //common parameters
        String urlToken = "https://oauth-login.cloud.huawei.com/oauth2/v3/token";
		//Callback url of application configuration
        String redirect_uri = "hms://redirect_url";
		//Appid of the application registered on the developer Alliance.
        String client_id = "300019777"; 
		//random number which used for verify the code,please refrencing the interface description for more details
        String code_verifier = "fdabfc91-5fdf-44d8-8dd9-a30cb6237dc22c83a904-20d0-43fc-91b6-1b7f9be4d6d0";
		//Public key assigned to the application by Huawei developer alliance after application creation,please refrencing the interface description for more details
        //String client_secret = "701e47383e6a108f86c9c05325fa8e6e",  
        //set value as "authorization_code"��meaning Use Authorization Code to get Access Token and ID Token		
        String grant_type = "authorization_code";
        String code = "DF2wE9qO3NVktCP3ELEadB33PgiKFgj3x9Vqh4Zq9Ij70V3OAy2cX6I/mTwY0Ui9Fb/4ItFBuuEnNklXVFB54vSDZKbvvoqs0nUHNkeLUOOwBKgo0jLj/l7BBJKXlZmXXuhqKKwd4X8U+eWpgRQQy2PWoktXCHcaWvmbLdBMdNR3AHJERQMOsbMuvmGNVGhudUiKDC9CHEWXd+xT6C2N/3vBStBOIjv+4phZid/pIyvxYssdx1y61qKn27LKA9gyAAmGCnpSA9BZRIdYoUq8nWArBPv0o9BC9GJmJ+2mUj8RFTrE2TNzPGsQwsZ9tZNKe1eN7dNE/H5Tvp1RdaGfmJwAILLPIMoVpj6UJmW/GRZTkLm9mxt0jKfZ+tRA5ijS8pnwQwbnjT2r74mJEnE8fIi4UV6ooNOoO42zh4Sn8AldQNbS9Bk";//�Ѿ����ɵ�code

        JSONObject tokens = getTokenByCode(redirect_uri, urlToken, code, code_verifier, client_id, "authorization_code");
        System.out.println("the output of oauth2/v3/token is : " + tokens.toJSONString());
    }

    private static JSONObject getTokenByCode(String redirect_uri, String urlToken, String code, String code_verifier,
                                             String client_id, String grant_type) throws IOException {
        HttpPost httpPost = new HttpPost(urlToken);
        List<NameValuePair> request = new ArrayList<>();
        request.add(new BasicNameValuePair("redirect_uri", redirect_uri));
        request.add(new BasicNameValuePair("code", code));
        request.add(new BasicNameValuePair("code_verifier", code_verifier));
        request.add(new BasicNameValuePair("client_id", client_id));
        request.add(new BasicNameValuePair("grant_type", grant_type));
        httpPost.setEntity(new UrlEncodedFormEntity(request));

        CloseableHttpResponse response = getClient().execute(httpPost);

        try {
            HttpEntity responseEntity = response.getEntity();
            String ret = responseEntity != null ? EntityUtils.toString(responseEntity) : null;
            JSONObject jsonObject = (JSONObject) JSON.parse(ret);
            EntityUtils.consume(responseEntity);
            return jsonObject;
        } finally {
            response.close();
        }
    }
    /**
     * get httpclient
     * @return
     */
    private static CloseableHttpClient getClient() {
        PoolingHttpClientConnectionManager connectionManager = buildConnectionManager("TLSv1.2", new String[]{"TLSv1.2","TLSv1.1"},
                new String[]{"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","TLS_DHE_RSA_WITH_AES_128_CBC_SHA256", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA", "TLS_DHE_DSS_WITH_AES_128_CBC_SHA"});
        connectionManager.setMaxTotal(400);
        connectionManager.setDefaultMaxPerRoute(400);
        RequestConfig config =
                RequestConfig.custom().setConnectionRequestTimeout(100).setRedirectsEnabled(false).build();

        return HttpClients.custom()
                .useSystemProperties()
                .setConnectionManager(connectionManager)
                .setDefaultRequestConfig(config)
                .build();
    }

    /**
     *
     * @param protocol
     * @param supportedProtocols
     * @param supportedCipherSuites
     * @return
     */
    private static PoolingHttpClientConnectionManager buildConnectionManager(String protocol,
                                                                             String[] supportedProtocols, String[] supportedCipherSuites) {
        PoolingHttpClientConnectionManager connectionManager = null;
        try {
            SSLContext sc = SSLContext.getInstance(protocol);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init((KeyStore) null);
            sc.init(null, tmf.getTrustManagers(), null);
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sc, supportedProtocols,
                    supportedCipherSuites, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslsf)
                    .build();
            connectionManager = new PoolingHttpClientConnectionManager(registry);
        } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
            e.printStackTrace();
        }
        return connectionManager;
    }
}
